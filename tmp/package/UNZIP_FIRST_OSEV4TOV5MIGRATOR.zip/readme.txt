Please see this wiki for instructions:

http://wiki.opensource-excellence.com/index.php?title=Documentation_-_OSE_Membership_5#Upgrade_from_version_4.4.x

Basically, please

1. Install OSE CPU, OSE Membership V5, and all OSE plugins and patches

2. Install this Migrator component

3. Upgrade the database in the migrator step by step, that's it.

