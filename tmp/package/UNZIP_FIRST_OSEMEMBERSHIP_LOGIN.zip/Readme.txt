Installation: 

1. Please login your Joomla! backend --> Extensions --> Extensions Manager --> Install / Uninstall

2. Browse the mod_oselogin_j15.zip file (if you use Joomla! 1.5) or mod_oselogin_j16.zip file (if you use Joomla! 1.6) and install it

3. After that, please go to Modules manager --> Enable the mod_oselogin module and change parameters as you wish. 

That's it. 
