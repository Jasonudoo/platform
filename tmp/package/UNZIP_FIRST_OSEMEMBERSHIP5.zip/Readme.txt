1. Online instructions:

https://www.opensource-excellence.com/documentation/tutorial-ose-membership.html

2. If any bugs are found, please report it by 

a) Logging in OSE website: https://www.opensource-excellence.com/
b) Access My Account area --> submit a support ticket:
https://www.opensource-excellence.com/member-support-request.html
c) Choose bug report in the support ticket option and submit a ticket

We will fix the bugs asap. 

3. Please note that Customization service has been closed:

https://www.opensource-excellence.com/services/ose-membership-customization-announcement.html

Please refer to these two wikis for instructions:

* How to customize the Registration Form layout?
http://wiki.opensource-excellence.com/index.php?title=How_to_customize_the_Registration_Form_layout%3F

* How to edit css?
http://wiki.opensource-excellence.com/index.php?title=How_to_edit_css%3F

* API
http://wiki.opensource-excellence.com/index.php?title=API_-_OSE_Membership_5

