Ext.onReady(function() {
	Ext.QuickTips.init();
	oseMsc.login.form.render('ose-login');
});
