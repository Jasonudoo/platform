Ext.onReady(function(){
	Ext.QuickTips.init();
	
	
	//oseMsc.payment.form.render('osemsc-payment-mode');
	oseMsc.payment.confirmForm.render('osemsc-payment-confirm');
	
	oseMsc.payment.viewButton.render('osemsc-payment-view-button');
	
	
})