Ext.ns('oseMsc','oseMsc.reg');
Ext.onReady(function(){
	Ext.QuickTips.init();
	
	oseMsc.reg.panel.render('osemsc-reg');
});