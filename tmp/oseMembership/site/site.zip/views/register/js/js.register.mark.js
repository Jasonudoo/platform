Ext.ns('oseMsc','oseMsc.reg','oseMsc.reg.mark');

oseMsc.reg.mark = new Ext.Panel({
	frame:false,
	plain:false,
});