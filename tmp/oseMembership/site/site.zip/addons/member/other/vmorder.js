Ext.ns('oseMscAddon');
	oseMscAddon.msg = new Ext.App();
	
	oseMscAddon.vmorder = new Ext.Panel({
		title: 'Order',
	});