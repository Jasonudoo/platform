<?php
defined('_JEXEC') or die(";)");
require_once(dirname(__FILE__).DS."register.payment.php");
class oseMscAddonActionRegisterPayment_var3 extends oseMscAddonActionRegisterPayment
{
}
?>