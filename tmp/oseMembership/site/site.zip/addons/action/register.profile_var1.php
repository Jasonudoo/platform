<?php
defined('_JEXEC') or die(";)");
require_once(dirname(__FILE__).DS."register.profile.php");
class oseMscAddonActionRegisterProfile_var1 extends oseMscAddonActionRegisterProfile
{
}
?>