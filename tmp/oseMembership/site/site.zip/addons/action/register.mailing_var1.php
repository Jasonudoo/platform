<?php
defined('_JEXEC') or die(";)");
require_once(dirname(__FILE__).DS."register.mailing.php");
class oseMscAddonActionRegisterMailing_var1 extends oseMscAddonActionRegisterMailing
{
}
?>