Ext.ns('oseMemMsc','oseMemMsc.add','oseMemMsc.edit');

oseMemMsc.msg = new Ext.App();
