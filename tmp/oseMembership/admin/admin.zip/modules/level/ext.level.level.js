Ext.ns('oseMsc','oseMscLevel');

	oseMsc.msg = new Ext.App();
