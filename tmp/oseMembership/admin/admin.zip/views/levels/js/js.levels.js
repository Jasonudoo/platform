Ext.onReady(function(){
	Ext.QuickTips.init();
	
	oseMscLevels.grid.render('osemsc-levels');
});