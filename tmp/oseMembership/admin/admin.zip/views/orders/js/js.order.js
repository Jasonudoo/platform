Ext.ns('oseMscOrders');
oseMscOrders.msg = new Ext.App();
