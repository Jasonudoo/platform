<?php
defined('_JEXEC') or die(";)");
class oseMscMigrate extends oseObject
{
	
}