<?php
defined('_JEXEC') or die(";)");
require_once(dirname(__FILE__).DS.'member_j15.php');
class oseMember_J16 extends oseMember_J15
{
}
?>
