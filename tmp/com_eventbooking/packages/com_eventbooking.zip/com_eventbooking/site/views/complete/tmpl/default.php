<?php
/**
 * @version		1.5.3
 * @package		Joomla
 * @subpackage	Event Booking
 * @author  Tuan Pham Ngoc
 * @copyright	Copyright (C) 2010 Ossolution Team
 * @license		GNU/GPL, see LICENSE.php
 */
// no direct access
defined( '_JEXEC' ) or die ;
?>
<h1 class="eb_title"><?php echo JText::_('EB_REGISTRATION_COMPLETE'); ?></h1>
<p class="info"><?php echo $this->message; ?></p>