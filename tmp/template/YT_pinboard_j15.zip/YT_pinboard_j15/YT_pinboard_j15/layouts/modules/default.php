<div class="<?php echo $suffix; ?>">
	<div class="module">
	
		<?php echo $badge; ?>
		<?php echo $extra_badge ?>
	
		<?php if ($showtitle) : ?>
		<h3 class="header"><?php echo $title; ?></h3>
		<?php endif; ?>
		<?php echo $content; ?>
		
	</div>
</div>